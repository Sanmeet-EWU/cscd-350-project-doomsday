## 5/8/25
### First standup:

Did:
- Learned Textual framework
- Created demo python console app in Textual
- Ported code (to color code syllables) to C#

Blockers:
- Planned C# console framework wasn't sufficient, so decided to switch to python
- Since we switched to Python's Textual, had to figure out how to bundle python and C# together in one exe

Next week:
- Make demo frontend and backend more dynamic (allow for choosing a file - not just sample-text)
- Learn more about Textual
