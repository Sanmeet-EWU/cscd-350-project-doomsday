Unit tests for the C# project can be found at src/Rhyme/Rhyme.Tests
